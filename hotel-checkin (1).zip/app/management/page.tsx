import { ManagementDashboard } from "@/components/management-dashboard"

export default function ManagementPage() {
  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">CitiNest Residence Management</h1>
      <ManagementDashboard />
    </div>
  )
}
