"use client"

import { useState } from "react"
import { format } from "date-fns"
import { CalendarIcon, Loader2, Luggage, User, KeyRound } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { Separator } from "@/components/ui/separator"
import { CheckCircle2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

type FormStep = "guest-info" | "reservation" | "confirmation"

interface FormData {
  firstName: string
  lastName: string
  email: string
  phone: string
  checkInDate: Date | undefined
  checkOutDate: Date | undefined
  adults: string
  children: string
  specialRequests: string
  roomPasscode?: string
}

export function HotelCheckin() {
  const [currentStep, setCurrentStep] = useState<FormStep>("guest-info")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState<FormData>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    checkInDate: undefined,
    checkOutDate: undefined,
    adults: "1",
    children: "0",
    specialRequests: "",
  })

  const updateFormData = (field: keyof FormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleNext = () => {
    if (currentStep === "guest-info") {
      setCurrentStep("reservation")
    } else if (currentStep === "reservation") {
      handleSubmit()
    }
  }

  const handleBack = () => {
    if (currentStep === "reservation") {
      setCurrentStep("guest-info")
    } else if (currentStep === "confirmation") {
      setCurrentStep("reservation")
    }
  }

  const generateRoomPasscode = () => {
    // Generate a 6-digit passcode
    return Math.floor(100000 + Math.random() * 900000).toString()
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Generate room passcode
    const roomPasscode = generateRoomPasscode()
    updateFormData("roomPasscode", roomPasscode)

    // In a real application, here we would save the guest data to a database
    // For example:
    // await saveGuestData({
    //   ...formData,
    //   roomPasscode,
    //   bookingReference: `CN-${Math.floor(100000 + Math.random() * 900000)}`,
    //   createdAt: new Date(),
    //   status: "upcoming"
    // });

    setIsSubmitting(false)
    setCurrentStep("confirmation")
  }

  const isGuestInfoValid = () => {
    return (
      formData.firstName.trim() !== "" &&
      formData.lastName.trim() !== "" &&
      formData.email.trim() !== "" &&
      formData.phone.trim() !== ""
    )
  }

  const isReservationValid = () => {
    return formData.checkInDate !== undefined && formData.checkOutDate !== undefined
  }

  const getStepIcon = (step: FormStep) => {
    switch (step) {
      case "guest-info":
        return <User className="h-5 w-5" />
      case "reservation":
        return <CalendarIcon className="h-5 w-5" />
      case "confirmation":
        return <CheckCircle2 className="h-5 w-5" />
    }
  }

  return (
    <Card className="w-full shadow-lg">
      <CardHeader>
        <div className="flex justify-between items-center mb-2">
          <div
            className={`flex items-center gap-2 ${currentStep === "guest-info" ? "text-primary" : "text-muted-foreground"}`}
          >
            <div
              className={`rounded-full p-1 ${currentStep === "guest-info" ? "bg-primary text-primary-foreground" : "bg-muted"}`}
            >
              {getStepIcon("guest-info")}
            </div>
            <span className="font-medium">Guest Info</span>
          </div>
          <Separator className="w-8 h-px" />
          <div
            className={`flex items-center gap-2 ${currentStep === "reservation" ? "text-primary" : "text-muted-foreground"}`}
          >
            <div
              className={`rounded-full p-1 ${currentStep === "reservation" ? "bg-primary text-primary-foreground" : "bg-muted"}`}
            >
              {getStepIcon("reservation")}
            </div>
            <span className="font-medium">Reservation</span>
          </div>
          <Separator className="w-8 h-px" />
          <div
            className={`flex items-center gap-2 ${currentStep === "confirmation" ? "text-primary" : "text-muted-foreground"}`}
          >
            <div
              className={`rounded-full p-1 ${currentStep === "confirmation" ? "bg-primary text-primary-foreground" : "bg-muted"}`}
            >
              {getStepIcon("confirmation")}
            </div>
            <span className="font-medium">Confirmation</span>
          </div>
        </div>
        <CardTitle>
          {currentStep === "guest-info" && "Guest Information"}
          {currentStep === "reservation" && "Reservation Details"}
          {currentStep === "confirmation" && "Booking Confirmed"}
        </CardTitle>
        <CardDescription>
          {currentStep === "guest-info" && "Please provide your personal details"}
          {currentStep === "reservation" && "Select your check-in and check-out dates"}
          {currentStep === "confirmation" && "Your check-in is confirmed and ready"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {currentStep === "guest-info" && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  placeholder="John"
                  value={formData.firstName}
                  onChange={(e) => updateFormData("firstName", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  placeholder="Doe"
                  value={formData.lastName}
                  onChange={(e) => updateFormData("lastName", e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="john.doe@example.com"
                value={formData.email}
                onChange={(e) => updateFormData("email", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                placeholder="+1 (555) 123-4567"
                value={formData.phone}
                onChange={(e) => updateFormData("phone", e.target.value)}
              />
            </div>
          </div>
        )}

        {currentStep === "reservation" && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Check-in Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !formData.checkInDate && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.checkInDate ? format(formData.checkInDate, "PPP") : <span>Select date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={formData.checkInDate}
                      onSelect={(date) => updateFormData("checkInDate", date)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2">
                <Label>Check-out Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !formData.checkOutDate && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.checkOutDate ? format(formData.checkOutDate, "PPP") : <span>Select date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={formData.checkOutDate}
                      onSelect={(date) => updateFormData("checkOutDate", date)}
                      initialFocus
                      disabled={(date) => (formData.checkInDate ? date < formData.checkInDate : false)}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="adults">Adults</Label>
                <Select value={formData.adults} onValueChange={(value) => updateFormData("adults", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select number of adults" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1</SelectItem>
                    <SelectItem value="2">2</SelectItem>
                    <SelectItem value="3">3</SelectItem>
                    <SelectItem value="4">4</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="children">Children</Label>
                <Select value={formData.children} onValueChange={(value) => updateFormData("children", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select number of children" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">0</SelectItem>
                    <SelectItem value="1">1</SelectItem>
                    <SelectItem value="2">2</SelectItem>
                    <SelectItem value="3">3</SelectItem>
                    <SelectItem value="4">4</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="specialRequests">Special Requests</Label>
              <Textarea
                id="specialRequests"
                placeholder="Any special requests or preferences?"
                value={formData.specialRequests}
                onChange={(e) => updateFormData("specialRequests", e.target.value)}
              />
            </div>
          </div>
        )}

        {currentStep === "confirmation" && (
          <div className="space-y-6">
            <div className="flex justify-center">
              <div className="rounded-full bg-green-100 p-3">
                <CheckCircle2 className="h-12 w-12 text-green-600" />
              </div>
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-xl font-medium">Thank you for your booking!</h3>
              <p className="text-muted-foreground">
                Your reservation has been confirmed. A confirmation email has been sent to {formData.email}.
              </p>
            </div>

            {/* Room Passcode Section */}
            <Alert className="bg-primary/10 border-primary">
              <KeyRound className="h-5 w-5 text-primary" />
              <AlertTitle className="font-semibold text-primary">Your Room Passcode</AlertTitle>
              <AlertDescription>
                <div className="mt-2">
                  <div className="bg-white p-4 rounded-md border-2 border-primary text-center">
                    <div className="text-sm text-muted-foreground mb-1">Use this code to access your room</div>
                    <div className="text-3xl font-mono font-bold tracking-widest text-primary">
                      {formData.roomPasscode}
                    </div>
                  </div>
                  <div className="mt-3 text-sm">
                    <p>Please keep this passcode secure. You'll need it to unlock your room door during your stay.</p>
                    <p className="mt-1">The passcode will be active from your check-in date until check-out.</p>
                  </div>
                </div>
              </AlertDescription>
            </Alert>

            <div className="bg-muted p-4 rounded-lg space-y-4">
              <div>
                <h4 className="font-medium">Reservation Details</h4>
                <Separator className="my-2" />
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="text-muted-foreground">Guest Name:</div>
                  <div>
                    {formData.firstName} {formData.lastName}
                  </div>

                  <div className="text-muted-foreground">Check-in:</div>
                  <div>{formData.checkInDate ? format(formData.checkInDate, "PPP") : "N/A"}</div>

                  <div className="text-muted-foreground">Check-out:</div>
                  <div>{formData.checkOutDate ? format(formData.checkOutDate, "PPP") : "N/A"}</div>

                  <div className="text-muted-foreground">Guests:</div>
                  <div>
                    {formData.adults} Adults, {formData.children} Children
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-medium">Booking Reference</h4>
                <Separator className="my-2" />
                <div className="bg-primary/10 p-2 rounded text-center font-mono">
                  CN-{Math.floor(100000 + Math.random() * 900000)}
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        {currentStep !== "confirmation" ? (
          <>
            <Button variant="outline" onClick={handleBack} disabled={currentStep === "guest-info"}>
              Back
            </Button>
            <Button
              onClick={handleNext}
              disabled={
                (currentStep === "guest-info" && !isGuestInfoValid()) ||
                (currentStep === "reservation" && !isReservationValid()) ||
                isSubmitting
              }
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing
                </>
              ) : currentStep === "reservation" ? (
                "Complete Booking"
              ) : (
                "Next"
              )}
            </Button>
          </>
        ) : (
          <Button className="w-full" onClick={() => window.location.reload()}>
            <Luggage className="mr-2 h-4 w-4" />
            Start New Booking
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}
