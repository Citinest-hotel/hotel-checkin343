"use client"

import { useState } from "react"
import { format } from "date-fns"
import { Search, Filter, Eye, Download, Trash2, Users, CalendarRange, KeyRound } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Guest type definition
interface Guest {
  id: string
  firstName: string
  lastName: string
  email: string
  phone: string
  checkInDate: Date
  checkOutDate: Date
  adults: string
  children: string
  specialRequests: string
  roomPasscode: string
  bookingReference: string
  createdAt: Date
  status: "checked-in" | "checked-out" | "upcoming"
}

// Sample data for demonstration
const sampleGuests: Guest[] = [
  {
    id: "1",
    firstName: "John",
    lastName: "Doe",
    email: "john.doe@example.com",
    phone: "+1 (555) 123-4567",
    checkInDate: new Date(2023, 4, 15),
    checkOutDate: new Date(2023, 4, 20),
    adults: "2",
    children: "1",
    specialRequests: "Late check-in, extra pillows",
    roomPasscode: "123456",
    bookingReference: "CN-123456",
    createdAt: new Date(2023, 3, 10),
    status: "checked-in",
  },
  {
    id: "2",
    firstName: "Jane",
    lastName: "Smith",
    email: "jane.smith@example.com",
    phone: "+1 (555) 987-6543",
    checkInDate: new Date(2023, 4, 18),
    checkOutDate: new Date(2023, 4, 25),
    adults: "1",
    children: "0",
    specialRequests: "High floor, quiet room",
    roomPasscode: "654321",
    bookingReference: "CN-654321",
    createdAt: new Date(2023, 3, 15),
    status: "upcoming",
  },
  {
    id: "3",
    firstName: "Robert",
    lastName: "Johnson",
    email: "robert.johnson@example.com",
    phone: "+1 (555) 456-7890",
    checkInDate: new Date(2023, 4, 10),
    checkOutDate: new Date(2023, 4, 12),
    adults: "2",
    children: "2",
    specialRequests: "Early check-in if possible",
    roomPasscode: "789012",
    bookingReference: "CN-789012",
    createdAt: new Date(2023, 3, 5),
    status: "checked-out",
  },
  {
    id: "4",
    firstName: "Emily",
    lastName: "Davis",
    email: "emily.davis@example.com",
    phone: "+1 (555) 234-5678",
    checkInDate: new Date(2023, 4, 20),
    checkOutDate: new Date(2023, 4, 27),
    adults: "2",
    children: "0",
    specialRequests: "Anniversary celebration",
    roomPasscode: "345678",
    bookingReference: "CN-345678",
    createdAt: new Date(2023, 3, 18),
    status: "upcoming",
  },
  {
    id: "5",
    firstName: "Michael",
    lastName: "Wilson",
    email: "michael.wilson@example.com",
    phone: "+1 (555) 876-5432",
    checkInDate: new Date(2023, 4, 12),
    checkOutDate: new Date(2023, 4, 16),
    adults: "1",
    children: "0",
    specialRequests: "Business trip, need desk space",
    roomPasscode: "901234",
    bookingReference: "CN-901234",
    createdAt: new Date(2023, 3, 8),
    status: "checked-in",
  },
]

export function ManagementDashboard() {
  const [guests, setGuests] = useState<Guest[]>(sampleGuests)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [selectedGuest, setSelectedGuest] = useState<Guest | null>(null)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)

  // Filter guests based on search term and status
  const filteredGuests = guests.filter((guest) => {
    const matchesSearch =
      guest.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      guest.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      guest.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      guest.bookingReference.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || guest.status === statusFilter

    return matchesSearch && matchesStatus
  })

  // Handle viewing guest details
  const handleViewDetails = (guest: Guest) => {
    setSelectedGuest(guest)
    setIsDetailsOpen(true)
  }

  // Handle deleting a guest
  const handleDeleteGuest = (id: string) => {
    setGuests(guests.filter((guest) => guest.id !== id))
  }

  // Get status badge color
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "checked-in":
        return <Badge className="bg-green-500">Checked In</Badge>
      case "checked-out":
        return <Badge variant="outline">Checked Out</Badge>
      case "upcoming":
        return <Badge className="bg-blue-500">Upcoming</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Guest Management</CardTitle>
          <CardDescription>View and manage guest information for CitiNest Residence</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all-guests" className="space-y-4">
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="all-guests">All Guests</TabsTrigger>
                <TabsTrigger value="checked-in">Checked In</TabsTrigger>
                <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
              </TabsList>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search guests..."
                    className="w-[250px] pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[180px]">
                    <Filter className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="checked-in">Checked In</SelectItem>
                    <SelectItem value="checked-out">Checked Out</SelectItem>
                    <SelectItem value="upcoming">Upcoming</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <TabsContent value="all-guests" className="m-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Guest Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Check-in Date</TableHead>
                      <TableHead>Check-out Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Booking Ref</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredGuests.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="h-24 text-center">
                          No guests found.
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredGuests.map((guest) => (
                        <TableRow key={guest.id}>
                          <TableCell className="font-medium">
                            {guest.firstName} {guest.lastName}
                          </TableCell>
                          <TableCell>{guest.email}</TableCell>
                          <TableCell>{format(guest.checkInDate, "MMM dd, yyyy")}</TableCell>
                          <TableCell>{format(guest.checkOutDate, "MMM dd, yyyy")}</TableCell>
                          <TableCell>{getStatusBadge(guest.status)}</TableCell>
                          <TableCell>{guest.bookingReference}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="icon" onClick={() => handleViewDetails(guest)}>
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => handleDeleteGuest(guest.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="checked-in" className="m-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Guest Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Check-in Date</TableHead>
                      <TableHead>Check-out Date</TableHead>
                      <TableHead>Booking Ref</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredGuests
                      .filter((guest) => guest.status === "checked-in")
                      .map((guest) => (
                        <TableRow key={guest.id}>
                          <TableCell className="font-medium">
                            {guest.firstName} {guest.lastName}
                          </TableCell>
                          <TableCell>{guest.email}</TableCell>
                          <TableCell>{format(guest.checkInDate, "MMM dd, yyyy")}</TableCell>
                          <TableCell>{format(guest.checkOutDate, "MMM dd, yyyy")}</TableCell>
                          <TableCell>{guest.bookingReference}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="icon" onClick={() => handleViewDetails(guest)}>
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => handleDeleteGuest(guest.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="upcoming" className="m-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Guest Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Check-in Date</TableHead>
                      <TableHead>Check-out Date</TableHead>
                      <TableHead>Booking Ref</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredGuests
                      .filter((guest) => guest.status === "upcoming")
                      .map((guest) => (
                        <TableRow key={guest.id}>
                          <TableCell className="font-medium">
                            {guest.firstName} {guest.lastName}
                          </TableCell>
                          <TableCell>{guest.email}</TableCell>
                          <TableCell>{format(guest.checkInDate, "MMM dd, yyyy")}</TableCell>
                          <TableCell>{format(guest.checkOutDate, "MMM dd, yyyy")}</TableCell>
                          <TableCell>{guest.bookingReference}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="icon" onClick={() => handleViewDetails(guest)}>
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => handleDeleteGuest(guest.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Guest Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Guest Details</DialogTitle>
            <DialogDescription>Complete information about the guest and their stay.</DialogDescription>
          </DialogHeader>

          {selectedGuest && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Personal Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Full Name</p>
                    <p>
                      {selectedGuest.firstName} {selectedGuest.lastName}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Email</p>
                    <p>{selectedGuest.email}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Phone</p>
                    <p>{selectedGuest.phone}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Booking Reference</p>
                    <p className="font-mono">{selectedGuest.bookingReference}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Booking Created</p>
                    <p>{format(selectedGuest.createdAt, "MMMM dd, yyyy")}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CalendarRange className="h-5 w-5" />
                    Stay Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Status</p>
                    <p>{getStatusBadge(selectedGuest.status)}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Check-in Date</p>
                    <p>{format(selectedGuest.checkInDate, "MMMM dd, yyyy")}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Check-out Date</p>
                    <p>{format(selectedGuest.checkOutDate, "MMMM dd, yyyy")}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Guests</p>
                    <p>
                      {selectedGuest.adults} Adults, {selectedGuest.children} Children
                    </p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Length of Stay</p>
                    <p>
                      {Math.ceil(
                        (selectedGuest.checkOutDate.getTime() - selectedGuest.checkInDate.getTime()) /
                          (1000 * 60 * 60 * 24),
                      )}{" "}
                      nights
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <KeyRound className="h-5 w-5" />
                    Room & Special Requests
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Room Passcode</p>
                    <p className="font-mono text-lg font-bold">{selectedGuest.roomPasscode}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Special Requests</p>
                    <p className="italic">{selectedGuest.specialRequests || "No special requests"}</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
